# vlbisim
A simple simulator for VLBI.

